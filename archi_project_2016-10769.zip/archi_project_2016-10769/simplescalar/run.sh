#!/bin/sh
./sim-outorder -bpred comb -cache:il1 il1:256:32:1:l -cache:il2
